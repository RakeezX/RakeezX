## AI candidate 0.5.18 — 20 October 2026

Each explicit Madrasati Start now adopts AVAILABLE teacher, principal/report-alias and school names, including differing existing values, under the same account/document/year/term/lease/CAS guards. Missing or ambiguous values never blank a profile. The persisted profile and its owner-bound outbox remain atomic; stale device-only name overrides are retired in that transaction so header and settings agree. Auth identity/email and unrelated device fields are untouched.

An explicitly labelled VISIBLE education-administration value from the supported teacher context may update only educationDepartment, using exact approved 47-directory labels. Unknown/ambiguous/missing values are reported without guessing a school region; existing calendar/year/term remain unchanged. No new portal routes, hidden APIs, background reads or permission grants.

Normal UI is one start/progress/result. Advanced/manual/diagnostic tools stay in closed details; wrong-page/login/unsupported/cancel states give a next action. Results distinguish updated/current/missing/conflicting/unsupported fields; safe support diagnostics contain only allowlisted field keys/reasons/counts. Old unresolved counts 1/3 alone cannot identify their historical fields or values.

Local actual-app/IndexedDB/extension evidence only. Existing accepted 303-student/deletion/slot/full-flow evidence is reused. Sole publisher must verify immutable/served 0.5.18, then existing stable updater installs the exact verified package; Chrome reload and this new live profile journey are not claimed here.

## AI candidate 0.5.17 — 20 October 2026

The explicit Start binds the existing authenticated application document and delivers to its shell receiver without changing its route or opening the import page. The app automatically resumes an exact saved same-owner/year/term batch after readiness using a fresh guarded grant; ambiguous class mappings remain optional manual recovery. No school routes, extraction rules or permissions changed.

Profile imports compare the hydrated persisted singleton inside one profile/outbox transaction and update memory only after commit. Conflicting values remain untouched. Unknown receipts carry only a finite failure phase/step/code into safe diagnostics; a profile-wide failure stops the batch instead of labelling every class unresolved. Compact fifth/sixth-grade names resolve only to unique matching existing destinations.

Synthetic actual-app/IndexedDB/controller/worker evidence covers storage rollback, postcommit unknown, duplicate-free saved-batch resume after reload, and foreign-account rejection. The real reported 0.5.16 journey remains FAILED. Live account success, publication, stable-folder 0.5.17 installation and Chrome reload are NOT_RUN by this worker; publication and subsequent stable update belong to the existing controller/publisher/updater.

## AI candidate 0.5.16 — 19 October 2026

- Transport checks the original document and account/session/year/term batch capability instead of an exact cached hash URL. A fresh deliberate Start can rebind the same current-account pending batch; workspace deactivation revokes the old capability.
- The existing visible-table adapters now retain an explicitly labelled class subject. The account-bound v3 payload carries available teacher, principal, school, class/subject and weekly timetable categories through existing guarded store paths. Conflicting profile/timetable values remain unchanged and are counted as unresolved. Missing source fields remain absent. No calendar-region switch or automatic daily sessions.
- This is synthetic/local evidence only. Actual school extraction/save, remote ACK and Production release are NOT_RUN. Unsupported source layouts/links remain unsupported. No new source route, permission, credential handling or automatic app-tab opening.
- Remaining blocker: current N77 server Delete requires a real existing teaching ID. Subjectless deletion cannot be enabled by a client-only fix without changing its approved server contract. No dummy subject/teaching, legacy/local delete or real mutation is used.
- The existing updater may advance only after the independent publisher verifies this immutable release; this worker does not change its stable folder.

## 0.5.12 — AI-authored one-start owned names batch (19 October 2026)

The explicit Madrasati Start now collects and imports every available class into the ONE already-open, authenticated Rakeez tab in the same window. Start binds that exact document, owner, session, year and term before collecting. There are no repeated class/review/save confirmations in this initiated batch. Noor and manual file/category paths retain their existing explicit review. The sole new host grant is `https://rakeezx.com/*`, needed to find and bind the existing receiver; no school host permissions, cookies, credentials or background collection are added. Reinstall/reload the genuine updated extension and accept its exact app-host permission when Chrome requests it.

Transport stays encrypted in extension-only session memory, one-time, exact-tab-bound, at most 300 names per envelope and expiring in two minutes. Expiry is never a required wait. On prompt claim the receiver durably stages pending names only in the bound account's existing local device record, then uses the normal guarded names import and real local readback. Counts-only receipts advance each class cursor. Duplicates preserve existing IDs/history/grades; an unknown result does not advance it. Pending classes survive transport expiry/reload and have an explicit owned resume action. Other resolvable classes can finish; the summary names actual unresolved classes and reports partial source coverage truthfully. No server Sync success is asserted.

Unambiguous, approved grade/section labels can create a section and its names roster without inventing a subject. Existing class names match only a unique owned active section; archived/tombstoned, ambiguous, invalid or unresolved labels require correction. Source navigation waits for readiness within bounded deadlines (not arbitrary long sleeps). The automatic run remains bounded to 30 minutes from the explicit Start; cancel/close revokes the app grant. Already committed names remain saved; cancel is not deletion.

The original accepted 303 names / 10 classes evidence and older packages remain immutable. Current proof uses only tiny fabricated classes and the actual installed extension, app DOM/CSS, owner guards and canonical store. Production publication and PO acceptance remain independent.

## 0.5.11 — AI-authored popup width and independent safe diagnostics (17 October 2026)

The ordinary action popup declares a stable 430 CSS-pixel root width independent of its initial viewport. The run tab remains responsive (320/390/1280 tested, body max 840). The top **نسخ معلومات التشخيص** button is bound by a first-loaded, external classic script with no ESM dependencies, inline code, extra permission or CSP change. User-click-only clipboard write produces bounded JSON with aggregate counts/enums, layout, module/background health and a six-entry sanitized error ring. No names, labels, identifiers, tokens, URLs, raw user agent, stack or arbitrary exception text enter the report. Clipboard refusal exposes a selectable safe report. Run cleanup clears ephemeral diagnostic aggregates and fallback text; copy does not change the collection.

The no-payload background health request follows the existing internal sender guard and performs no storage, alarm, tab or handoff operation. Actual installed headless Chromium loaded the MV3 worker/protocol and all three page entry graphs under the manifest CSP. A native action popup page was not exposed by that owned headless engine: **NATIVE_ACTION_POPUP_NOT_RUN**. The HTTP shrink regression is separate evidence, not certification of the user's native Chrome window. The user-reported “Failed to load the script unexpectedly” at handoff-protocol.js:0 was not reproduced; its root cause remains **UNKNOWN**. Neither a missing file nor fixed Chrome error is claimed. No user browser, school account or clipboard content was read.

Versioned 0.5.11 ZIP/manifest bind 25 actual runtime files; older archives remain intact. The central download version alone changes, preserving delivered N107's extension-first/single-review flow. Publisher/provider/Production and subsequent natural stable-folder update remain separate, unrun delivery phases. The accepted own-account 303 total is unchanged; generic terminal evidence and real saved receipts remain open.

## 0.5.10 — AI-authored concise class review (17 October 2026)

Normal run: Start → gathered names/classes → academically sorted class and names preview → **راجعت الأسماء — نقل الفصل إلى ركيز** → existing Rakeez review/confirmation/save. The transfer click explicitly confirms review and consent for the displayed class/batch. Private module state binds the visible roster/class/offset across asynchronous source preflight; class/context/cancel/expiry changes invalidate it. Unknown/partial coverage retains one separate acknowledgement. No expected-total field, parser/completeness inference, new permission or automatic save. Source preview remains ephemeral for five minutes; transport remains one-time/two minutes and at most 300 names per selected class batch, without a source-total cap. JSON/CSV/manual categories and safe diagnostics stay in one collapsed advanced section.

PO 17 October 2026 13:55 confirms **303 is the official total for his own account**, collected across ten classes/seven pages in 0.5.9. His full-roster count is accepted on that direct confirmation. This is separate from generic structural pagination proof: his observed page 7 endpointKind=none remains unproven by the parser for other teachers. No hardcoded 303 or complete=true was introduced. Actual Rakeez saved receipts for the overall N36 journey remain unverified/open.

0.5.10 has a separate source/file/archive manifest; earlier packages are preserved. The independent publisher owns delivery and served package verification. Only after publication can the existing RAKEEZ-N36-Verified-Local-Update scheduled task naturally synchronize the stable folder; its disk receipt must then be checked. This local candidate cannot prove a future stable-folder update. The worker does not run a manual updater, access school/student accounts, attach to user Chrome, install or reload it. The teacher presses Reload once after the verified new version is ready.

## 0.5.9 — AI-authored explicit terminal compatibility (17 October 2026)

Supports an active `span.page-link` and an explicitly labelled disabled Next span in the bounded report pager. Preserves the observed anchor/SVG/sr-only/ellipsis baseline. Unknown or contradictory ends remain partial; neither 303 rows nor seven visible pages proves an official total. Safe optional pagination diagnostics contain fixed counts, booleans and enums only. No school/account trial or save is certified by this synthetic correction.

## 0.5.8 — AI-authored collection-before-review correction (17 October 2026)

One explicit read run accumulates validated observed report pages before class selection. Normal 350/1000 multi-class runs no longer stop at 300 names. Transport remains at most 300 names from one selected source class; authenticated N12 review and explicit confirmation remain required. Reading never proves saving or Sync.

Resource slices: 24 processed pages or 90 seconds, at most three report requests, eight-second request timeout, 2,000,000 response bytes before parsing, and an 8 MiB accounted source-memory budget (UTF-8 row bytes plus 256 bytes per row allowance). A resource-only “جمع المزيد” continuation retains all prior vetted rows, series, counters and identity; no class receipt is required. The earliest ephemeral expiry remains five minutes from the first retained names (or an earlier resource pause), across every continuation. Transport retains its independent two-minute ceiling. Memory exhaustion produces a truthful partial subset, never an estimated total or complete coverage. Cancel, expiry and unsafe context changes erase names and abort owned requests. No persistent source names/fingerprints.

The final ordered class selector shows actual class counts, gathered total and proved/partial/unknown coverage. Optional metadata discovery cannot delay review after a proved report terminal. The accepted 0.5.7 comparator and encrypted one-time owner/term/lease-safe receiver remain unchanged. Official source/save acceptance remains voluntary and NOT_RUN by this synthetic worker; N36 remains OPEN.

## Current private 0.5.7 — academic order and honest report coverage (AI)

Class choices compare grade 1–12, then natural section numbers (1, 2, 10), without renaming or changing identities, membership, within-class student order or persisted record order. The comparator is copied byte-for-byte from src/lib/class-order.js and its equality is checked by tests/n36-academic-class-order.test.mjs; no model/store runtime is bundled.

A 300-row review window is a pause, not an overall roster cap. When validated report routes remain, the teacher must review and explicitly confirm every current batch in Rakeez and wait for its receipts before continuing. A missing receipt never advances or discards an unsent tail. A network/schema failure remains partial; missing terminal/gaps/unknown totals cannot prove completion. A proved terminal report series is complete even at exactly 300 rows or with only optional MyStudents/metadata work remaining. Missing child links on optional MyStudents cannot negate independently proved report coverage. Local receipts are not server-save/Sync proof.

Download 0.5.7 from Koshoof; previous packages remain untouched. The independent publisher verifies publication; only then may the separately authorized stable-folder updater run. This worker does not install or reload Chrome. Official full-source collection and saved import acceptance remain voluntary PO checks; N36 is OPEN.

## Historical release notes below

Earlier limits and package references below describe historical versions, not the current contract.

# Current 0.5.5 — PO partial available decision, 2026-10-17

This section supersedes the historical complete-only and total-cap descriptions below. There is no product-wide maximum number of students. Source rows are reviewed in bounded transient windows (pause at 300 valid rows, at most 599 valid rows when a page crosses the boundary). A source table larger than 300 is read in sequential visible row slices. Each exact class is split into <=300-row transfers, preserving source order. The teacher explicitly confirms partial coverage and every batch, maps the source class to a verified owned class, and confirms names inside Rakeez. Missing index links, unknown terminal or a missing later page warn about coverage; they do not invalidate independently vetted visible name/class rows. Invalid, hidden and ambiguous rows stay excluded, with bounded reasons and no invented missing count.

Continue is enabled only when every valid row in the current window has a confirmed receiver outcome. A send/claim is never a save receipt. Saved/existing counts come from the actual owner-bound modal after its existing guarded transaction and fresh review. Failed, uncertain, expired, cancelled or lost receipts never advance a cursor; the teacher can explicitly retry the same rows. Rakeez rechecks existing names before each action, including an all-existing acknowledgement without a new write. Counts mean local persistence/readback, not server Sync certification. Receipt return is restricted to the original receiver tab/nonce, contains only bounded counts and expires after the original two-minute handoff deadline. Only encrypted names use extension session storage; receipt records contain no names. No names are stored durably.

Collection resumes only on explicit Continue and fresh source guard. Each review expires after five minutes and scrubs the source window, DOM, pending transport and cursors; restart is voluntary and receiver deduplication still applies. No personal Chrome profile, new school permissions or official account testing is authorized. The fixed installed runtime is updated only by the verified operator after Production; this source package does not update it. Official-source end-to-end success still requires a voluntary PO test. N36 remains OPEN.

## Historical implementation notes (earlier versions)

## Private 0.5.3 — staged roster evidence and strict completeness (AI implementation)

A run distinguishes names accumulated in memory, complete names available for review, and names committed to Rakeez (zero in this helper). A later missing source page never turns 300 accumulated names into a claim of an empty roster. Excluded names are discarded; only bounded aggregate counts and safe exclusion codes remain in the diagnostic. No names, URLs, school identifiers or source HTML are added to storage or diagnostics.

A complete roster needs every page in each observed report series and an explicit terminal pager, stable source origin/school/teacher context, no repeated page or student identity, and at most 300 validated student rows. Known visited routes are skipped; an unvisited MyStudents discovery page is still checked because it may contain another report. Completion of one report or reaching 300 is never proof that the whole source is complete.

Overflow keeps the 300-row category and per-action transfer caps. The helper blocks the entire student transfer and explains the observed lower-bound row count, without claiming it is a count of unique students. No automatic truncation, segmented import or new storage is implemented. A complete <=300 roster still requires explicit review, the existing one-time two-minute handoff, and Rakeez owner/class matching and confirmation. Active non-teacher role changes also block reads and export.

The current package is 0.5.3. Keep both published 0.5.1 and 0.5.2 packages as rollback; no old fallback is regenerated. The sole publisher first verifies provider and Production asset parity. Only the existing verified update-stable.ps1 operator workflow then updates the ONE stable folder; the user explicitly clicks Chrome Reload. This worker does not update a personal folder/profile or deploy. The official N36 task remains OPEN until the PO verifies a real authenticated roster/import.

The older sections below document previous versions and are historical; follow this section for the current update.

## Private 0.5.2 — Chrome popup and review usability (AI implementation)

The action popup now has a definite 430px CSS width; the separate RTL run page fits small screens and grows to 840px. A missing verified student roster keeps transfer disabled and the other categories collapsed under «تفاصيل البيانات الأخرى (اختياري)». Zero preview students does not prove an empty class, and iframe presence does not prove roster location. No source parsing/routes/permissions changed.

The review lasts exactly 300 seconds with a remaining-time display. Expiry removes staged values and date/time picker DOM, explains the deletion in Arabic, and offers guidance to voluntarily reopen the toolbar popup from the source tab. The independent transfer token still lasts only two minutes after explicit transfer. Student rows, when present, remain visible for explicit review; edits invalidate confirmation.

Download 0.5.2 from Rakeez Koshoof. Initial installation: unzip into one dedicated folder and use Chrome → Extensions → Developer mode → Load unpacked. Keep one helper enabled. The existing guarded updater may update the stable folder only after a separate verified Production receipt; this worker never modifies or reloads a personal extension. Keep the untouched 0.5.1 ZIP and manifest for rollback.

Evidence is synthetic installed Chrome only. Real teacher Chrome retest and full direct Madrasati roster compatibility remain OPEN. Noor remains the second phase; JSON remains advanced. No account/owner/Sync/grade or portal operations changed.

---
Historical version notes follow; installation instructions below are historical.

## Private 0.5.0 — teacher-reviewed direct names handoff (AI implementation)

Built from the committed 0.4.5 extension at `0246d892de99ff66c8106d37b77678136cc3cacf`. The route policy, source report reader, pagination, MyStudents skip, teacher settle, 90-second run and source-origin/role bounds remain unchanged. The sections below are historical version notes, not current installation instructions.

Install only by the user's explicit action: unpack the complete 0.5.0 ZIP to a new dedicated folder, verify the accompanying `rakeez-teacher-import-helper-0.5.0.manifest.json` and hashes, then use Chrome Extensions → Developer mode → Load unpacked. Do not overwrite the existing stable extension folder, auto-reload it, or use a personal profile in automation. Only one intended helper should be enabled when the teacher runs it. No fixed extension ID: the installed extension obtains `chrome.runtime.id` itself.

Madrasati: use the existing explicit current-tab start on `https://schools.madrasati.sa`. Noor: on `https://noor.moe.gov.sa/Noor/`, select the visible student-name column header yourself, enter its class label and explicitly confirm teacher authority. Noor reads that visible column only, does not navigate, read other tabs/columns or call private APIs, and is always labelled partial. Review/edit/deselect the resulting names, check the final review, then click **نقل إلى ركيز**. Only STUDENTS names and class labels transfer; other categories remain available for the existing explicit local export.

The primary handoff opens Rakeez's existing Koshoof import tab in the same browser. A 256-bit random nonce and device-specific extension ID appear in the hash, never names, class labels or credentials. A two-minute single-use envelope lives only in trusted `chrome.storage.session`, bound to the exact new app tab and exact `https://rakeezx.com/` URL. It is deleted before claim response, on cancel/tab close, or by expiry alarm; browser restart clears session storage. No service request or automatic app write. The app validates schema/provenance/caps, binds an authenticated owner and current teaching, and reuses the existing explicit one-class checkbox/store commit/partial receipt safeguards. Cancel or expired/changed source gives harmless guidance; CSV/JSON local export remains an advanced fallback.

Permissions are activeTab + scripting (the existing user-triggered source run), storage + alarms (only the short-lived handoff). No host permissions, content scripts, cookies, clipboard transfer, cloud relay, background school reads, Auth/RLS/service changes, or real student tests. A worker stores no envelope until the teacher clicks Transfer.

Synthetic installed-extension proof is separate from real official-account compatibility. Neither complete official Noor/Madrasati extraction nor N36 Product acceptance is claimed. No previous denied official-browser/report operation was retried.

---
Historical notes follow.

## Private 0.4.5 — partial-run corrections

The actual user 0.4.4 result contained one teacher plus 20 timetable rows; it did not prove student collection or full live timetable correctness. Three local defects are now corrected: a validated MyStudents sidebar/self GET is ignored during report discovery; mirrored report pagers may display different numeric windows when their current/next/terminal evidence agrees; and a selected teacher-card transition gets one bounded eight-second DOM-settle phase even when its intermediate document is complete without a spinner. No role transition is sent twice. Selected-card metadata is withheld until teacher context is verified. Login/origin/admin/school changes stop; timeout is explicitly TEACHER_TRANSITION_UNRESOLVED.

Only actual allowed same-report GET hrefs are followed. Generic numeric navigation is not a pager by itself. Compatible page evidence is merged, not the first pager chosen. The original all-pages completeness, repeat and context/filter checks remain. Existing redundant page-one hrefs are deduplicated by identity only; the navigated href and its filters are never rewritten. A missing report remains unavailable; unsafe candidates still stop. The ordinal timetable extraction block is byte-identical to candidate 20e0d4cde337694fbc8c6681e0b31e9c637dfc44.

Evidence under coverage/n36-partial-repair preserves installed 0.4.4 failures (sidebar, mirrored windows, silent intermediate page), one actual 0.4.5 mixed run with six categories/seven students/one class/20 synthetic timetable rows and explicit JSON export, plus focused contradictory-pager, missing-middle, repeat, changed-scope, external, login/admin/school, timeout and cancel negatives. Local output is not official account certification. The exact live pager variant remains unobserved beyond the supplied evidence. Initial harness failures are preserved; only failed/unrun cases continued with hard-stop assertions retained.

The 19-file 0.4.5 package has two explicit alternative update preimages: prior verified dedicated 0.4.4 and stable 0.4.3. Operator must match the complete selected preimage, preserve drift/unknown files, stage and verify the new files, then separately decide to Reload. This worker did not update any live/dedicated/user folder or personal profile. No automatic Reload, publication, Rakeez save or new permission. The prior report-write rejection remains FAIL history, not retried. Official/current-account extraction and Rakeez account-save remain NOT_RUN/unimplemented.

## Private 0.4.4 final timetable adapter (same staged version)

The operator supplied the visible empty-corner/Arabic ordinal headers and one lesson-card structure. The reader now maps explicit ordinal or numeric period labels, verifies weekday row cells, and reads subject from `.schedule-card > .title > h2` and classroom from its direct `small`. It preserves empty cells and expands supported colspan. It never follows the enclosing preparation link or interprets `done`/icons as attendance, grades or lesson data. Multiple visible cards, ambiguous subject/class, duplicate/unknown periods and invalid day/span exclude the timetable with a precise diagnostic. Missing time stays absent from JSON.

Actual installed-extension proof is under `coverage/n36-ordinal-timetable`: old 0.4.4 baseline failure retained; 10 focused mixed-flow timetable cases passed, including explicit JSON field equality, empty/merged slots and ambiguous negatives. The one-page roster fixture is only a mixed-flow companion; completed seven-page/gateway/Name/SchoolId evidence is reused, not rerun. Runtime files other than the timetable source reader are unchanged from candidate 783d277ba29842ed1a246396eb750fa872f57776. The first companion fixture omitted its active-page marker; that harness failure remains preserved after correction.

Final runtime/source ZIPs and candidate-bound update manifest are prepared separately under `coverage/n36-ordinal-timetable`, against stable 0.4.3. Earlier staged 0.4.4 artifacts remain preserved and are superseded by this final candidate, never overwritten. The previous report-write denial remains FAIL history and was not retried. Full official-account extraction validation and real Rakeez account-save remain NOT_RUN; supplied header/card inspection is partial source evidence only. No live folder/profile/account modification or public release.

## Private 0.4.4 — observed teacher-card routes and accessible seven-page pager

Press **ابدأ الاستيراد من مدرستي** once from your selected visible school page. A single explicit teacher card can select its already-entitled teacher session through its own exact ChangeUserTypeToTeacherFromParent href; this selection affects the portal session. Multiple teacher schools require one school choice. Other role switches remain prohibited. No automatic startup/background capture was added.

Only the operator-observed MyStudents and TeacherSchedule GET routes accept their one source-bound SchoolId. The selected role-target identifier is kept separate from SchoolId; no identifier, Name or URL is manufactured. The shared route policy is used by the controller and page reader. Loading/redirect waits never re-dispatch the role switch. Login, origin and contradictory-role changes stop the run.

The observed active LI contains a numeric child anchor plus a screen-reader '(current)' sibling; the reader preserves accessibility DOM and reads that numeric child. Existing ellipsis/SVG-arrow hrefs are understood. Completion requires actual terminal evidence and every page from 1 to the terminal page, never the maximum visible number. Missing pages, repeated response/URL, changed school/filter or exceeded bounds exclude the whole student category. Limits remain 24 pages/run, 90 seconds collection, 300 rows/category, 600 total bundle rows and 5-minute review. A larger roster is not silently truncated or marked complete.

Gateway h5 school title and explicitly labelled principal survive the handoff. A unique visible school badge or complete uniquely labelled roster school column can supply school; classes derive only from complete student rows. Names, classroom and requested school fields are retained; IDs, contacts, guardians and other raw columns are excluded. Every result remains editable/deselectable and requires explicit review/download. There is no real Rakeez account save.

The actual timetable href plus header and one lesson-card structure are operator-observed. The corresponding visible adapter is locally proved; full live-week output remains unverified. Existing labelled schemas remain supported; unknown layouts are visibly incomplete. Local fixtures are synthetic, never official end-to-end certification.

Update the same extension entry: operator verifies all 19 expected previous **0.4.3** file hashes, stages reviewed 0.4.4 files, checks the candidate-bound UPDATE_MANIFEST, replaces only matching owned files, and presses Reload. Preserve unknown files/hash drift and old folders; finish/cancel active runs first. This worker does not update n36-current, inspect a personal profile or install in the user's Chrome. No uninstall/reinstall loop or cloud updater.

## Private 0.4.3 — numeric pagination and exact redacted rejection diagnostics

Use the same explicit **ابدأ الاستيراد من مدرستي** action. Numeric/active page links, equivalent top/bottom pagers and explicit end states are supported without requiring a literal status sentence. Only existing same-report GET hrefs are followed, with every non-page filter unchanged. Missing end/next, conflicting pagers, changed filters or repeated content exclude the entire student category. Absence of a pager is not a one-page claim.

The explicit Copy diagnostic control now includes BOTH entry counts and a fixed route template, known query-key names and bounded reason. Values, arbitrary keys, identifiers, hrefs and handler code are never copied or sent. Unknown official gateway/query shapes remain unsupported until safely observed; this package does not widen the route/query policy. No actual official DOM compatibility or Rakeez account-save integration is claimed.

Operator update only: verify every expected 0.4.2 hash in the new verified-update-stage/UPDATE_MANIFEST.json, stage all 19 matching runtime files, verify new hashes, then Reload the same extension entry. Preserve drift/unknown files and old folders. The worker does not modify n36-current or the personal profile; no uninstall/reinstall loop. Finish/cancel an active run before updating. Review/edit/deselect before an explicit JSON/CSV download; there is no automatic import/save.

## Private 0.4.2 — visible context and GET-link discovery are separate

The two permitted entry path forms do not dictate which UI is shown. A coherent bound school/role/Homepage relationship is treated as school selection on either path; coherent teacher navigation/action controls are treated as an already-active teacher dashboard on either path. Multischool choice, explicit contradictory roles, login/session, source-tab/frame identity and origin checks remain. Names/hostnames/unrelated labels alone do not establish context.

Read links are classified separately. Only actual known same-origin report hrefs with allowed query semantics are used through direct safe GET/tab navigation. An inline onclick attribute is counted, never read/evaluated/clicked: its presence alone does not reject an otherwise known read href. JavaScript/empty/foreign/unsupported/query-rejected/form/write/ChangeUserType/send destinations are not followed; no IDs/URLs are constructed. Gateway Homepage hrefs still require the bound card and one of the observed permitted entry routes.

If the dashboard is recognized but no safe destination exists, the error is **link-discovery / READ_LINKS_UNAVAILABLE**, not missing teacher role. A category whose link is rejected remains visibly uncollected; independently valid categories can be previewed. Diagnostic counts are bounded href/empty/javascript/query-rejected/inline-handler/read-path/origin/form classifications, never hrefs, handler strings, query values, HTML or names. No handler executes to discover a destination.

Use the verified 0.4.2 update stage and expected previous **0.4.1** runtime hashes. Operator stages/hash-checks, updates only matching owned stable files and reloads the same extension entry after cancelling/finishing runs. The worker never modifies live n36-current or installs in a personal profile. Official DOM and real Rakeez account commit remain NOT_RUN; this is private local preparation only.

## Private 0.4.1 — presentation-invariant entry; staged update only

The entry classifier supports the observed teacher gateway route using the bounded lowest shared scope of explicit role label/value, school information and one actual safe Homepage href. It does not require a `.card`/`.panel` class. Repeated nested text is one semantic role, principal metadata is not active authority, and cross-card/ambiguous binding remains unresolved. Multiple genuine schools still require one explicit choice. Arabic bidi controls/colon spacing and harmless icon children do not change the role/label meaning.

On exactly `/Dashboards/Schools`, independent student/daily-followup navigation and timetable/report-or-class-followup controls plus two distinct actual safe GET read links can establish the shown teacher dashboard, including when top navigation is outside main or neutral wrappers change. A name, generic homepage, lone control or plain scattered text does not suffice. Existing explicit contradictory-role/login/OTP/origin/write safeguards remain. No URL/ID, hidden role selector or frame is invented.

The original source tab is captured before creating the run page. The actual `tabs.get` result and frame-0 injection result must match that binding. Entry status/Copy diagnostics expose only pageKind, readyState, sourceTabMatch and bounded expected-marker/iframe counts. No names, hrefs, text, IDs or document identifiers. Iframe count is an observation only: the helper still injects top frame only and does not assume that a real user's failure is an iframe/wrong-tab issue.

0.4.0 source roster/pagination/timetable module remains byte-identical. This update is staged under `coverage/n36-entry-invariant/update-stage/`, with reviewed runtime files and an UPDATE_MANIFEST containing expected previous/new hashes. It does **not** modify the live user-loaded `n36-current` folder. Operator finishes/cancels a run, verifies every existing owned file against the previous manifest, stages/hash-checks this package, replaces only matching owned files, verifies new hashes and reloads the same extension entry. Preserve unexpected files/hash drift; no blind overwrite or uninstall/reinstall loop.

Official current DOM and actual Rakeez metadata/timetable commit remain NOT_RUN; Noor/messaging remain unimplemented. Local fixtures are synthetic screenshot-semantic examples, not captured official DOM or proof of a personal-browser correction.

## Private 0.4.0 — labelled source reports, completeness and one stable folder

One Start still binds the chosen teacher school and original source tab. The new independent reader supports actual observed `/SchoolManagmentReports/StudentInfo/ClassStudentInfo/<id>` hrefs without constructing paths/IDs. It maps visible **اسم الطالب / اسم الطالبة / اسم الطالب/ة** and **الفصل / الصف والفصل** headers (or one explicit الفصل: caption), accepts harmless nested visible text in `td.project-title`, and never reads other raw student columns. Unknown positional 9-column data stays unresolved; national IDs, accounts, guardian contacts and hidden fields are excluded.

Pagination uses actual same-path GET hrefs and explicit visible **الصفحة N من M** boundaries, preserving the other query parameters. It checks contiguous pages, terminal boundary, repeated page content and deduplicates allowed name/class pairs only. A missing/disabled/changed page, unknown report boundary or timeout excludes the entire incomplete category from export and says **جمع جزئي غير مكتمل**. This does not establish student identity or authorize account merging; full identity matching remains a later Rakeez Preview gate.

Timetable content is awaited in the visible original tab for up to six seconds, with progress/cancel and session/origin guards. Supported forms: explicitly labelled day/period-or-time/class/subject rows, or an explicit day/numbered-period grid whose lesson cells have الفصل: and المادة: labels. A colspan repeats a labelled lesson only over the actual explicit covered period headers; rowspans, ambiguous groups and overflow remain unresolved. No iframe, POST/API, anti-CSRF or hidden-state access is used.

### Stable private handoff/update

The task produces `coverage/n36-current/runtime` and `coverage/n36-current/UPDATE_MANIFEST.json`, separate from every old 0.3.x directory. Operator can provide this **one n36-current location**. The manifest records release/source ZIPs, source diff and every runtime SHA256. No personal-browser install/update was performed by the worker.

Initial teacher-controlled setup: Extensions → Load unpacked → this stable runtime folder, then Start from the authorized homepage and review/edit/deselect before explicit local export. Future updates retain this path and extension entry: finish/cancel a run, verify the existing manifest and all files, stage a reviewed package separately, replace only the manifest-owned runtime files after matching old hashes, verify the new hashes, then press Reload on that same extension entry. Do not uninstall/reinstall per version, overwrite old user-loaded 0.3.x folders, or update an active run. Unexpected files/hash drift require preserving that folder and resolving the difference; never delete or overwrite unknown content.

### Noor is a separate future adapter — NOT IMPLEMENTED

Uploaded source uses `StudntNamesReport.aspx`, ddlClass/ddlSpecialty/ddlSection, View and pagination with ASP.NET WebForms postbacks and PageRequestManager busy/completion. A future authorized adapter must bind visible chosen class/specialty/section, distinguish read-only report postbacks from writes, wait for matching document/async checkpoints, prove every page/row boundary and cancellation/expiry, and remap **labelled names/class only**. Its report discovery and postback authority/official surface require separate verification. Do not detect/import civil IDs, persist source-account state or reuse that source's broad raw-row/foreign-receiver behavior. Noor is not supported by the current GET adapter and has not been tested here.

Current official Madrasati DOM and real Rakeez metadata/timetable account commit remain NOT_RUN. Uploaded source was studied as behavior/selector evidence without executing/rebranding third-party code or retrying a denied profile read. No public release, automatic cloud save or added extension permissions.

## Private 0.3.3 — school-card gateway and teacher dashboard

This private build supports the newly screenshot-evidenced structures: one visible teacher school card bound to its own safe الصفحة الرئيسية href, or /Dashboards/Schools with a coherent teacher navigation/action landmark combination. It does not require a teacher suffix in مرحبا بك [name]. Global مدارس الأبناء chrome and labelled principal metadata are not the user's active role. Explicit admin/parent-only/login/OTP states still stop. Only actual visible validated GET links are followed; no role/API URL or identifier is constructed.

Open the helper from the intended source tab and press **ابدأ الاستيراد من مدرستي**. One eligible school card proceeds automatically; multiple distinct teacher schools show one school-choice screen. That choice is rechecked against the current source document before navigation. Cancel clears it. The final editable/deselectable preview contains only unambiguous teacher/school/principal values and supported student/timetable fields, excluding email/IDs/totals. Missing fields remain missing. Unsupported roster/schedule structures stop with a safe count/boolean diagnostic rather than an empty-success claim. Copy is explicit and never sends data.

The fixtures are synthetic equivalents of screenshots, not captured official DOM. Actual official compatibility and Rakeez metadata/timetable account-save integration remain unverified. The worker did not visit school pages, install in a personal browser, or read a denied competitor package. Keep existing versions/folders intact. The separate 0.3.3 runtime is loaded through Extensions → Load unpacked when deliberately authorized; Start/Preview/Copy require no DevTools commands. No public distribution or automatic account write.

## Private 0.3.2 — recovered reference role adapter

This separate private build recognizes teacher-role synonyms, identical duplicate role links, or one visible short composite greeting ending in معلم/معلمة together with safe same-origin TeachersReports hrefs. It follows only actual visible GET links; it never constructs MyInfo paths/IDs or uses the recovered Bookmarklet's iframe/receiver. Conflicting admin roles, ambiguous greetings/destinations without a reliable current-role signal, login/OTP and origin/route restrictions still stop collection. A greeting/name is role evidence only and is never a teacher-name export; exported names still require the existing explicit field label.

For missing/ambiguous role errors, use **نسخ التشخيص الآمن** beside the diagnostic. It copies only version, reason, greeting/active-role booleans and safe-link/role-destination counts, never names, hrefs or DOM. Nothing is sent automatically. If still stopped, repeating the same operation cannot supply the missing structural evidence.

Private handoff: extract the separate 0.3.2 ZIP into a new folder; in Chrome/Edge Extensions enable Developer mode and choose **Load unpacked / تحميل إضافة غير مضغوطة** for that folder. Keep only the intended helper version enabled when deliberately testing. Do not overwrite the installed 0.3.0/0.3.1 folders. From the authenticated start tab, open this helper and press **ابدأ الاستيراد من مدرستي**; review/edit/deselect the final preview before any explicit local export. No DevTools commands are required. The worker never installs into a personal profile.

Synthetic reference-shape proof is not verification of the current official DOM. Actual Rakeez metadata/timetable commit integration remains unimplemented/unverified; no automatic account import, public release or N36 closure is claimed.

# N36 private route correction — v0.3.1

**Private local correction; official DOM and direct Rakeez metadata/timetable commit integration still NOT_RUN.** v0.3.0 is preserved, including its ZIP/runtime. The separate v0.3.1 ZIP/runtime is under `coverage/n36-route-diagnostics/`; do not hotpatch or Reload the user's installed folder. No personal browser or school page was accessed here.

The starting source tab ID is captured before the extension run page is created. One rejected **same-origin optional** auxiliary link no longer aborts independent allowed collection: that link is never visited/read, and the UI explicitly reports its category/link as uncollected and the result as partial. No new route/query/host is allowed. A rejected mandatory teacher route, cross-origin link/transition, login or role ambiguity/change still stops and clears. Actual redirected/current routes are checked again before private read. Existing navigation.js origin/path/query controls are byte-identical to v0.3.0; the correction changes failure categorization, not the route allowlist.

For a route rejection, the small local diagnostic shows extension version, stage (`start-path`, `role-selection`, `auxiliary-link`, or `navigation-redirect`), reason/category, redacted route template and safe unknown query **key names only**. Only fixed semantic path vocabulary and a conservative safe parameter-name vocabulary survive; identifiers, names, email, values, high-entropy/unknown segments and unsafe key names are redacted/omitted. This vocabulary is diagnostic-only and grants no route permission. Press **نسخ التشخيص الآمن** to copy that line deliberately; it is not sent automatically. If a rejection persists, this sanitized line can identify a narrowly scoped missing route decision; repeating the same run is not a repair. Never send a raw URL, token, cookie, storage or page HTML.

Normal use remains one Start action and the final edit/deselect/review/export flow below. Partial collection is not official compatibility or a claim that skipped data was imported. See `docs/automation-evidence/20261014/N36_ROUTE_DIAGNOSTICS.md` for the actual installed-extension reproduction, new checks, package/diff hashes and retained gates. CSV/parser/N12 evidence is reused unchanged. No account writes, service operations, publishing or installed-user-folder mutation are part of this handoff.

## Preserved v0.3.0 one-start workflow (optional-link failure handling superseded above)

# N36 private one-start helper — v0.3.0

**Private local preparation, N36 OPEN.** This update replaces the primary manual page/column-selection workflow with one explicit user-started read-only run. Official current teacher DOM/personal installation and direct Rakeez metadata/timetable commit integration remain **NOT_RUN**. The worker never accessed an actual school account, personal browser or installed user folder. v0.2.0 archive and prior candidate remain untouched; v0.3.0 is a separate ZIP/runtime folder, not a hotpatch.

## New private package and ordinary use

The reviewed package is `coverage/n36-one-start/rakeez-teacher-import-helper-private-0.3.0.zip`; its separate unpacked folder is `coverage/n36-one-start/private-0.3.0/runtime/`. Exact hashes/diff and local proof are in `docs/automation-evidence/20261014/N36_ONE_START_IMPORT.md`. Keep the old installed v0.2.0 folder intact. Only after the verified private package handoff, load the new folder separately through Chrome/Edge Extensions → Developer mode → Load unpacked. No DevTools commands, pasted JavaScript, cookies or credentials are needed. No personal installation was performed by this worker.

1. Open your authenticated Madrasati homepage normally. Open the extension from that tab and press **ابدأ الاستيراد من مدرستي**. Opening Chrome, opening the popup, or restoring an old run page does not start extraction.
2. A separate extension page shows progress and cancellation while the **same source tab** visits visible, recognized read-only links. You do not select table columns or navigate pages manually. The run requires either an explicit active teacher-role label, or one unambiguous visible teacher-role link followed by a confirmed teacher role. It never switches to an administrator role, submits forms or clicks write/grade/attendance actions.
3. Visible links labeled بياناتي / معلوماتي / البيانات الشخصية, فصولي / الفصول الدراسية / الفصول التي أدرسها, قائمة الطلاب / أسماء الطلاب / طلاب الفصل, and جدولي / جدولي الأسبوعي / الجدول الأسبوعي define the allowed read-only destinations. Same-origin next-page links are bounded/deduplicated. Generic unknown controls and guessed routes are not followed. A login/OTP prompt, role ambiguity, unsafe link or cross-origin transition stops and clears the run; renew the user action from an authorized homepage rather than supplying a token.
4. The final aggregated preview reuses the editable category/field/row selection. Missing teacher/school/principal values remain missing; principal is never inferred from the homepage or another person's name. Vertical label/value rows, definition lists and unambiguous horizontal role headers are supported. Classes, roster and timetable require exact recognized headings; classroom may also come from an explicit `الفصل: …` caption/section heading. A conflicting/ambiguous category is shown missing/unresolved, not silently kept from its first page.
5. Edit/deselect, check final review, then explicitly download JSON or the chosen student names CSV. Any edit invalidates consent; source/login/expiry is rechecked before export. JSON includes only selected allowlisted categories, `version:1`, and category provenance `teacher-readonly-run` (no HTML/full URL/identity/contact/marks). CSV retains the existing BOM/header/names-only N12 format. When using N12 within one Rakeez class, choose the matching classroom's rows in the final preview, then review the N12 import; JSON preserves classroom context. Nothing is committed to Rakeez here.
6. Cancel/clear, source-tab closure, logout, changed origin or expiry clears staged data. Export completion clears the run preview. Close the extension run page to discard it. Review expires after five minutes; a run is capped at 24 pages, 90 seconds, 300 rows/category and 600 total rows. Exact repeated page rows are deduplicated, conflicting slots/roles remain unresolved. A second run on the same source tab is refused while the first is collecting or awaiting review.

## Scope and route evidence

The current start-origin policy uses the **actual action-invoked tab**, HTTPS and the exact Ministry-linked host `schools.madrasati.sa`, as published in the Ministry-hosted [distance-learning report](https://www.moe.gov.sa/ar/education/studies/Documents/NDLP.pdf). The public reference establishes an allowlisted root, not current authenticated teacher DOM compatibility. No search-result hostname suffix or unverified subdomain is trusted. Explicit loopback origins with ports exist solely for the local synthetic fixture. The run never navigates to an origin other than its actual start origin, even if another domain is official. Unsupported starts stop rather than redirecting to a guessed portal. Noor and other origins are not certified by this phase.

Chrome's [activeTab contract](https://developer.chrome.com/docs/extensions/develop/concepts/activeTab) permits continued access across same-origin navigation and revokes it on an origin change. Permissions remain **activeTab+scripting** only. The run lives in its explicit extension page and uses an ephemeral BroadcastChannel launch handshake; there is no background/service worker, storage.session/localStorage, durable school state, broad tabs/cookies permission, host wildcard, fetch/XHR/cloud transport or startup read. In-memory queue paths are necessary only during the bounded run and are cleared afterwards; diagnostics contain domain/category/counts, not full URLs or page HTML. Closing/restoring the run page cannot automatically resume collection. Time fields continue to use the exact approved Rakeez date/time adapter, not a competing picker.

New checks are `node --test tests/n36-navigation.test.mjs` and lease-owned `tests/n36-one-start-browser.mjs`; the latter has narrow remaining-guards/lifecycle/exclusive/metadata/limits/deadline modes to preserve completed evidence. `tests/n36-one-start-package.mjs` builds/verifies the separate allowlisted package/runtime and preserves the old ZIP hash. The actual installed-action test uses native CDP `Extensions.triggerAction` on the owned synthetic tab, then real popup mouse input; no Chrome API mock or unsafe-debugging flag is used. Old v0.1/v0.2 browser proofs remain historical and are not repeated unchanged.

## Historical v0.2.0 instructions/evidence (superseded primary workflow)

# N36 private teacher setup helper — v0.2.0

**Private local capability only; N36 remains OPEN.** Current official homepage/roster/timetable DOM, personal browser installation and actual Rakeez metadata/timetable import are **NOT_RUN**. No public release or account save is provided. This version extends the previous committed helper; the original names-only core and N12 format are retained. The historical v0.1 receipt below describes that previous candidate, not readiness of v0.2.

## Install and use without DevTools commands

For a separately authorized private trial, unzip `rakeez-teacher-import-helper-private-0.2.0.zip` into a folder. In a fresh disposable Chrome/Edge profile, open the browser's Extensions page (`chrome://extensions` or `edge://extensions`), turn on Developer mode, choose **Load unpacked**, and select the folder containing `manifest.json`. Pin/open “ركيز — مساعد إعداد المعلم التجريبي الخاص” from the Extensions menu. This does not authorize installation in a personal teacher profile; that is a later verification gate. No console/DevTools code, credentials or OTP are required.

1. Choose exactly one category in the popup. For **أسماء الطلاب فقط**, use the existing CSV route; each name can now be edited or excluded, then reviewed again. Choose the file in Rakeez N12 Preview and explicitly review before adding.
2. For a structured category, deliberately paste a visible Tab-separated table, or on an authorized supported page select the text of the category's first visible header and press **استخراج المحدد ومعاينته**. The selected-table reader supports generic plain semantic tables, not a certified official portal adapter. No crawling, pagination or navigation occurs. The synthetic loopback fixture is permitted; real-page support is currently limited to the original exact Madrasati HTTPS allowlist. Noor and other origins remain unsupported/unverified.
3. Teacher, school and principal use one explicit label/value row: `اسم المعلم<Tab>القيمة`, `اسم المدرسة<Tab>القيمة`, or `اسم المدير<Tab>القيمة`. A generic “الاسم” or another role's label is unresolved. For a page selection choose the label cell in a plain two-cell visible row. No person role is guessed.
4. Classes use heading `الفصل`. Students use `اسم الطالب<Tab>الفصل`; all other columns are omitted. Timetable uses `اليوم<Tab>الحصة<Tab>الوقت<Tab>الفصل<Tab>المادة`, with at least period OR time. Exact weekday labels are الأحد، الاثنين، الثلاثاء، الأربعاء، الخميس، الجمعة، السبت. Period is 1–20; time is `08:00` or `08:00-08:45` with valid increasing times and 0–9 digits. Missing headings/values, unknown days or ambiguous slots stay visibly unresolved. Edit/paste the correctly labeled visible data; the helper invents nothing.
5. Review every field. Edit values and uncheck fields/rows you do not want. Required fields cannot be silently omitted; exclude the row instead. Check review and press **احتفاظ مؤقت**. Multiple class/student/timetable pages can append reviewed rows; duplicates and conflicting day/period or day/time slots block append. A new teacher/school/principal preview explicitly replaces that category's prior name. Everything stays in popup memory; closing it clears the session. Keep the popup open while staging, or prepare a combined pasted table. This is not persistent browser session storage.
6. The staged categories remain editable and deselectable. Choose only desired categories/rows/fields, check final review and press **تنزيل JSON للفئات المختارة فقط**. Any edit invalidates consent. **إلغاء المعاينة** clears only the current draft; **مسح الكل** clears all staged content. There is no automatic file, navigation or Rakeez save.

## Versioned local envelope and safeguards

JSON has only `schema: "rakeez-private-teacher-setup"`, `version: 1`, and `categories`. Each chosen category has `category`, `provenance` (`pasted-visible` / `selected-visible` only), and allowlisted rows. Teacher/school/principal rows have `name`; classes have `classroom`; students have `name,classroom`; timetable has `weekday,period/time,classroom,subject`. No HTML, full URLs, identifiers, contacts, marks, cookies, storage, tokens or tracking metadata are exported. JSON is a private review artifact, **not an implemented Rakeez metadata/timetable import format**.

Bounds: 2–80 characters for text/names, 300 rows per category, 600 total rows, 100000-character input/envelope. Names reuse the original conservative letter/mark/space grammar. Names/classes and timetable slots have normalized duplicate checks. Source cells must be visible/plain/unmerged; hidden rows are excluded. Permissions remain only activeTab+scripting; no default content script, background service, broad host permission, analytics, network or durable storage. Page access exists only after the Extract button; pasted content stays local and is cleared after preview/error/cancel. Editable previews intentionally retain chosen values until cancellation/closure.

Time preview reuses exact copies of `src/lib/rakeez-datetime.js`, `rakeez-datetime-values.js` and the existing licensed flatpickr assets. The interval is edited as start/end time controls using `data-rakeez-datetime="time"`; end is optional. Existing digit normalization and optional-time validation are preserved; no date policy, competing picker or native-only time input is introduced. The approved CSS has only its local import path adjusted; popup CSS bounds the picker to the narrow viewport. Press **إغلاق اختيار الوقت** before switching between the two time controls if the open picker overlaps another field. These are private extension dependencies, not changes to the application's startup or offline shell.

Current checks: `node --test tests/n36-categories.test.mjs`; lease-owned `tests/n36-expanded-browser.mjs`, `tests/n36-csv-edit-browser.mjs` and `tests/n36-time-controls-browser.mjs`; `node tests/n36-private-package.mjs`. Do not replay completed evidence unchanged. The old `tests/n36-private-browser.mjs` is pinned to the historical source and must not be used against the expanded tree. ZIP contains only fourteen runtime files and the flatpickr license; no README/tests/data/secrets.

## Historical v0.1 evidence (unchanged)

# N36 private names-only helper prototype

State: LOCAL_READY candidate, **UNVERIFIED_OFFICIAL_DOM**. Not a Production extension, not N36 CLOSED. Base: `d0bea326cb37d7c7d360521e8fc81c41d50b92d2`; owner/task: `v5-n36-official-names-helper-20261012`, branch `pm/n36-official-helper-20261012`. Authority: current scoped synthetic/local MVP instruction under D-094; real teacher portal/account access and public release are excluded.

## Behavior and privacy boundary

- Arabic RTL popup. No page read at startup. Teacher manually opens an authorized Madrasati tab, selects text inside a first-row name header, opens the extension action and explicitly requests preview. Generic semantic HTML tables only; no invented private portal selectors. Only top frame, isolated execution world. No scrolling, pagination, source writes, login or automatic discovery of tables.
- Exact HTTPS allowlist: `madrasati.moe.gov.sa`, `madrasatibeta.moe.gov.sa`. Noor, other origins, frames, nonstandard ports and unsupported layouts are intentionally refused. This is a prototype allowlist, not a claim of verified current teacher routes.
- Alternatively paste a Tab-separated table, including exactly one `اسم الطالب`, `اسم الطالبة` or `اسم الطالب/ة` header on the first row. No HTML/CSV/XLSX parsing in this helper. For exported XLSX, use N12 directly. Prefer pasting only the names column; pasted input is transient and cleared on preview/error/cancel.
- Direct extraction never reads non-name data-cell text. Hidden rows are excluded and counted. Nested tables, merged/irregular cells, decorated or hidden name cells, cancellation and unclear headers fail closed. Plain single-column name tables work. No grades, attendance, IDs or phone fields in output.
- Only letter/mark/space names, 2–80 characters, up to 300 names. Numbers, stray numbering, punctuation, formula characters and directional controls fail the whole preview. Empty cells are counted/skipped; duplicates (including spacing/tatweel/diacritic equivalence) block the whole output rather than silently dropping students. Unsupported names must be reviewed through official XLSX/N12.
- Full temporary names preview, explicit review checkbox, one-time client-generated UTF-8 BOM CSV Blob download. Source edit or cancellation invalidates the preview and in-flight reads. Object URL revoked. Popup closure discards in-memory state. The downloaded file remains on the teacher's device until they remove it.
- MV3 permissions only `activeTab` and `scripting`. No persistent host permissions, service worker, default content scripts, credentials, cookies, OTP, storage API, analytics, remote SDK, fetch/XHR/WebSocket or cloud upload. CSP `connect-src 'none'`. No RAKEEZ navigation, names in URLs, account/database writes or automatic import.

Official public service descriptions supplied by the task say authenticated teachers can view/export class records and export the final gradebook: [class records](https://madrasatibeta.moe.gov.sa/services/class-gradebook-records?Language=1), [final gradebook](https://madrasatibeta.moe.gov.sa/services/final-gradebook-record?Language=1). Those descriptions do not establish teacher access to principal user-management exports or private table DOM compatibility. No external account/site was accessed.

## Existing N12 route

Inside RAKEEZ open the class → الطلاب → استيراد الطلاب, select `rakeez-student-names.csv`, inspect the names and duplicate diagnostics, then explicitly confirm الإضافة. Existing `src/lib/student-import.js` parser/preview is used by the focused compatibility test; no app code changed. The helper does not apply, match or double-write students.

## Focused local check

From the worktree: `node --test extensions/rakeez-teacher-import-helper/tests/helper.test.mjs` (built-in Node only, no install/build). Synthetic Arabic fixtures and fake DOM cover mixed sensitive columns with read traps, byte-exact CSV/N12 compatibility, empty/zero names, duplicate/number/formula/control/long names, cancellation/races, hidden rows, nested/merged/decorated cells, click-only execution, one output and static no-network/permission policy. Fake DOM/source checks are not a real browser or official portal test.

## Exact trusted-PM next gate

Sandbox browser lease attempt stopped before acquisition: `Get-CimInstance Win32_Process` in canonical `scripts/ops-supervisor-v4/common.ps1:20` returned `Access denied`, HRESULT `0x80041003`. No browser was started, no lease acquired, no owned browser resources to clean/release. Per task instruction this denial was not retried or bypassed. Synthetic browser/visual Preview is **NOT_RUN**, handed off to trusted PM with exact source SHA in the result receipt.

Acquire the canonical task's browser lease using `scripts/ops-supervisor-v4/resource-lease.ps1`. Release in `finally` after cleaning only task-owned resources. On the trusted host inspect/package this exact committed extension directory without `tests/` or this README for a private unpacked Chrome/Edge test profile; no external extension store/release. Do not install into a teacher/personal profile under this task.

Synthetic browser smoke: open the unpacked popup on an offline synthetic page or extension popup URL; paste the mixed TSV fixture from the test; verify Arabic RTL layout, full review, checkbox, one file, cancellation, no network, and CSV via existing N12 synthetic Preview without applying a real account write. Also verify the official-origin rejection on a nonofficial tab. Do not fake the official URL to claim official compatibility. DOM injection remains mock-verified until a separately authorized teacher test on an actual official page.

Before any Production extension release obtain exact authority for a teacher-controlled authorized test, verify real domain/DOM/layout and pagination behavior without credentials collection, confirm exclusions and N12 review route, then perform required privacy/packaging/browser gates. Keep `officialPortalVerification: NOT_RUN` and `UNVERIFIED_OFFICIAL_DOM` until evidence changes. No Production eligibility or CLOSED claim from this MVP. N36 ownership remains reserved for the PM delivery stage or documented external blocker.


## 0.5.6 — AI-authored, 17 October 2026
Teacher-triggered ClassStudentInfo GETs run in the source tab isolated world, up to three concurrent requests, with eight-second per-request timeout. Only observed exact-report links are admitted; no report-page navigation/fallback, credentials inspection or new permissions. Inert HTML uses the same labelled name/class/school parser with static hidden-node exclusions, not live getClientRects. Review windows remain ephemeral for five minutes; per-class explicit Rakeez confirmation and local/existing/unknown receipts remain mandatory. Failed pages retain a partial subset, never fabricated completeness. Official continuation and real-account saving remain NOT_RUN; N36 OPEN.
